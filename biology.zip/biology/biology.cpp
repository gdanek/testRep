#include<iostream>
#include<fstream>
using namespace std;
int main(){
    cout << "create a list of coordinates (write 1 if yes, 0 if no)?\n";
    bool flag;cin >> flag;
    ifstream fin;fin.open("E_coli.txt");
    ofstream fout;if(flag)fout.open("graph_points.txt");
    char x;long long y = 0,_max = 0,_min = 0,iter = 0;
    long long _minLR[2] = {0,0},_maxLR[2] = {0,0};
    bool _minStart = 0, _maxStart = 0;
    while(fin >> x)
    {
              ++iter;
              if(x == 'G')++y;
              else if(x == 'C')--y;
               if(_max != y) _maxStart = 0;
              _max = (_max < y)? y : _max;
              if(_max == y){if(_maxStart)_maxLR[1] = iter;else{_maxStart = 1;_maxLR[0] = iter;}}
              if(_min != y)_minStart = 0;
              _min = (_min > y)? y : _min;
              if(_min == y){if(_minStart)_minLR[1] = iter;else{_minStart = 1;_minLR[0] = iter;}}
              if(flag){fout << x << " " << y << endl;}
    }
    if(flag)fout.close();
    if(flag)cout << "\nlist of coordinates successfully created!\n";
    cout << "minimum value: " << _min << " in line " << _minLR[0] << ":" << ((_minLR[1] > _minLR[0])?_minLR[1]:_minLR[0]) << endl;
    cout << "maximum value: " << _max << " in line " << _maxLR[0] << ":" << ((_maxLR[1] > _maxLR[0])?_maxLR[1]:_maxLR[0]) << endl;
    cout << "\ndone! Enter any character to close the program \n ";
    char b;cin >>b;
return 0;}
